"use client"
import {GlassCard} from '@developer-hub/liquid-glass'

export default function Landing() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="min-h-screen flex flex-col items-center justify-center">
        <GlassCard 
          padding="10px"
          displacementScale={100}
          blurAmount={1}
          cornerRadius={16}
          className="min-w-lg mx-auto"
        >
        <div className="text-center ">
          <h1 className="">
            Agamjot Singh
          </h1>
          <p className="text-2xl md:text-4xl font-bold text-white">
            Computer Science @ SJSU
          </p>
        </div>
        </GlassCard>
      </section>
    </div>
      
  );
}
    

